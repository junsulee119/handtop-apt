"""rg35xxh-inputd: turns the RG35XX H controls into mouse/keyboard (desktop mode) or an
Xbox-style controller (gamepad mode). Runs inside the labwc session as the user.

Devices (grabbed exclusively while running):
  "H700 Gamepad"              buttons + sticks (+ rumble motor)
  device with KEY_VOLUMEUP    volume keys (gpio-keys)
  device with KEY_POWER       power button (AXP717)
Virtual devices (uinput): mouse, keyboard, and in gamepad mode an Xbox 360 pad.
External controller modes (BT Controller: rg35xxh-btpad, wired: rg35xxh-usbpad, Switch:
rg35xxh-usbpad --switch over USB, rg35xxh-switchbt over Bluetooth) use the gamepad mapping too, but send the pad events over a Unix socket to
that service instead of creating the local pad, so apps on the handheld see nothing. Only one of
the services runs at a time.
"""
import json
import logging
import math
import os
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time

import evdev
from evdev import ecodes as E
from evdev import ff
from gi.repository import GLib

from . import config
from . import focus
from . import macros
from .core import PAD_AXES, Core, PointerLayout

log = logging.getLogger("rg35xxh-inputd")

GAMEPAD_NAME = "H700 Gamepad"
BUILTIN = {GAMEPAD_NAME: "gamepad", "gpio-keys-volume": "volume", "axp20x-pek": "power"}
GRAB_TRIES = 5                 # a device busy at start-up (usually the previous daemon still
GRAB_RETRY_S = 0.5             # letting go) is tried again for ~2 s before giving up
# Physical codes (rocknix-singleadc-joypad, see docs/hardware.md) -> button names.
HW_BUTTONS = {
    0x131: "a", 0x130: "b", 0x134: "x", 0x133: "y",   # all four verified on device (debug log)
    0x136: "l1", 0x137: "r1", 0x138: "l2", 0x139: "r2",
    0x13d: "l3", 0x13e: "r3", 0x13a: "select", 0x13b: "start", 0x13c: "f",
    0x220: "up", 0x221: "down", 0x222: "left", 0x223: "right",
    E.KEY_VOLUMEUP: "vol_up", E.KEY_VOLUMEDOWN: "vol_down", E.KEY_POWER: "power",
}
HW_AXES = {E.ABS_X: "lx", E.ABS_Y: "ly", E.ABS_RX: "rx", E.ABS_RY: "ry"}
TERMINALS = ("foot", "footclient", "org.codeberg.dnkl.foot", "xterm", "uxterm", "kitty", "alacritty")
STATUS_LED = "/sys/class/leds/red:status"
EXT_SOCKET = "/run/rg35xxh-extpad.sock"        # created by rg35xxh-btpad / -usbpad (root, group input)
# Messages from the service: b"hello bt" | b"hello usb" | b"hello switch" | b"hello switch-bt"
# first, later b"rumble <big> <small>" (0-255).
EXT_MODES = {   # transport: (flag file, notification title, notification text, taskbar icon)
    "bt": ("rg35xxh-bt-mode", "BT Controller mode",
           "Controls go to the paired PC/phone. Select + Start + L1 + R1 to stop.", "bt"),
    "usb": ("rg35xxh-wired-mode", "Wired Controller mode",
            "Controls go to the PC over the USB cable. Select + Start + L1 + R1 to stop.", "wired"),
    "switch": ("rg35xxh-wired-mode", "Switch Controller mode",
               "Controls go to the Switch over the USB cable. F: Home, F + Select: Capture. "
               "Select + Start + L1 + R1 to stop.", "wired"),
    "switch-bt": ("rg35xxh-bt-mode", "Switch Controller mode (Bluetooth)",
                  "Controls go to the Switch over Bluetooth. F: Home, F + Select: Capture. "
                  "Select + Start + L1 + R1 to stop.", "bt"),
}
EXT_HELLO = {b"hello usb": "usb", b"hello switch": "switch", b"hello switch-bt": "switch-bt"}   # else "bt"
SWITCH_EXTS = ("switch", "switch-bt")           # F gives Home / Capture there
# Battery saver in external controller modes: the status screen (rg35xxh-controller-screen
# --saver) switches the handheld's display off while connected. Vol / F + Vol / Power are the
# only presses not sent to the other device, so they wake it: the daemon writes EXT_WAKE, which
# the screen watches. EXT_DARK exists while the display is off; if the screen died meanwhile,
# the daemon switches the display back on when the mode ends.
EXT_WAKE, EXT_DARK, EXT_OUTPUT = "rg35xxh-extpad-wake", "rg35xxh-extpad-dark", "DSI-1"
BT_EVENT = struct.Struct("<HHi")               # evdev type, code, value
# Mode-change feedback: the taskbar icon shakes and the motor wobbles with it, both driven from
# here on one clock and one damped-spring model, x(t) = A e^(-DECAY t) sin(2 pi FREQ t):
#  - icon: the OLD mode's icon is shown at each swing peak (every half period = STEP_MS, sides
#    alternating; offsets rounded to whole pixels, e.g. 2 -2 1 -1 1 -1), then the new icon;
#  - motor: one pulse per swing, strength following the spring's decaying envelope.
# The motor is an ERM on one PWM line (strength = duty cycle), slow to spin up and without
# braking, so the pulses blur into a decaying wobble. Waybar redraws ~HAPTIC_LAG_MS after a
# signal (it re-runs rg35xxh-inputmode), so the pulses are delayed by that much to line up.
SPRING_FREQ, SPRING_DECAY, SPRING_AMP_PX = 8.33, 3.85, 2.6    # Hz, 1/s, px
SPRING_SWINGS, SPRING_STEP_MS = 6, 60                         # 60 ms = half a period
SPRING_PULSE_MS, SPRING_FLOOR = 40, 0.4                       # pulse length; weakest strength
HAPTIC_LAG_MS = 70
HAPTIC_RESCALE_MIN_S = 0.3
STICK_WANT, STICK_FEED = "rg35xxh-controls-sticks.want", "rg35xxh-controls-sticks"
STICK_WANT_MAX_AGE = 2.0       # s: the app refreshes the want flag every second
STICK_FEED_TICKS = 3           # write every 3rd 10 ms tick: ~30 times a second     # haptic_strength changes: re-upload the pulses at most this often


def _spring(t):
    return math.exp(-SPRING_DECAY * t) * math.sin(2 * math.pi * SPRING_FREQ * t)


_PEAKS = [(k + 0.5) * SPRING_STEP_MS / 1000 for k in range(SPRING_SWINGS)]
ICON_FRAMES = [max(-2, min(2, round(SPRING_AMP_PX * _spring(t)))) or (1 if _spring(t) > 0 else -1)
               for t in _PEAKS]                               # px; frames exist for -2..2
SPRING_PULSES = [round(SPRING_FLOOR + (1 - SPRING_FLOOR) * math.exp(-SPRING_DECAY * t), 2) for t in _PEAKS]
INPUTMODE_FRAME = "rg35xxh-inputmode-frame"
# Hiding the pointer outside desktop mode: labwc has no "hide cursor" action, but it hides the
# pointer after touch input until the next real pointer motion. So on entering gamepad / BT
# Controller mode a short-lived virtual touchscreen taps once at the top-left corner, onto our own
# 2x2 px transparent overlay window shown there just for that moment, so the tap reaches nothing
# else (an earlier version tapped the taskbar border and opened tray icons). The pointer is warped
# there and hidden; it shows again as soon as the stick moves it in desktop mode.
# Motor safety: changing the vibration many times a second (re-uploading the effect) locked up
# the whole system twice (kernel side: ROCKNIX joypad driver, ff-memless + PWM work). Games and
# the PC can ask that fast (SDL re-sends rumble every frame; test pages stream it), so every
# vibration coming from outside (games in gamepad mode, the PC in wired mode) goes through one
# gate: at most one hardware update per MOTOR_INTERVAL, always with the latest request, and
# strengths rounded to MOTOR_LEVELS steps. Handtop's own short haptics are not affected.
# Never endless effects either: an effect with replay length 0 ("until stopped") locked the system
# up even at a few updates a second (all three freezes had one; our fixed-length haptics never
# did). So every effect has a length, and long vibrations are re-triggered (MOTOR_REFRESH) while
# wanted. Wired mode pre-uploads one MOTOR_EFFECT_MS effect per level and only plays/stops them.
MOTOR_INTERVAL = 0.1           # s
MOTOR_LEVELS = 8
MOTOR_EFFECT_MS = 500          # PC vibration: per-level effect length
MOTOR_GAME_MAX_MS = 1000       # games: length used for an endless (0) effect
MOTOR_REFRESH = 0.4            # s: re-trigger interval while a long vibration is wanted
TOUCH_W, TOUCH_H = 640, 480
TOUCH_TAP = (0, 0)                   # "<mode> <dx>" while shaking
WAYBAR_SIGNAL = 8                              # image#inputmode in the Waybar config


def runtime_flag(name):
    return os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), name)


def set_flag(name, on):
    """Runtime flag files, read by rg35xxh-autosleep and the Waybar input-mode indicator."""
    if on:
        open(runtime_flag(name), "w").close()
    else:
        try:
            os.unlink(runtime_flag(name))
        except FileNotFoundError:
            pass


def _comm(pid):
    try:
        with open(f"/proc/{pid}/comm") as f:
            return f.read().strip()
    except OSError:
        return None


def _proc_age(pid):
    """Seconds since process pid started (0 if unknown)."""
    try:
        with open(f"/proc/{pid}/stat") as f:
            start = int(f.read().rsplit(")", 1)[1].split()[19]) / os.sysconf("SC_CLK_TCK")
        with open("/proc/uptime") as f:
            return float(f.read().split()[0]) - start
    except (OSError, ValueError, IndexError):
        return 0


def spawn(*argv):
    """Start a program and forget it. A thread waits for it so it never lingers as a zombie: a
    finished wlogout left behind made rg35xxh-power-menu's `pgrep -x wlogout` think the menu was
    still open, so the taskbar's power button closed it instead of opening it (2026-11-11)."""
    try:
        p = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError as e:
        log.warning("cannot run %s: %s", argv[0], e)
        return None
    threading.Thread(target=p.wait, name=f"reap-{argv[0]}", daemon=True).start()
    return p


class Daemon:
    def __init__(self):
        self._loop = None
        self.cfg_stamp = config.stamp()
        cfg = config.load_layers()
        self.trial_until = cfg.trial_until
        self.hw = cfg.hardware
        self.core = Core(cfg.settings, cfg.bindings)
        self.haptic_scale = self.core.s["haptic_strength"]   # strength step_ids were uploaded at
        self.layout = PointerLayout()   # per-screen pointer speed (rg35xxh-display writes the layout)
        self.layout_mtime = None
        self.devices = []          # grabbed physical devices
        self.gamepad = None
        self.absinfo = {}
        self.dropped = set()       # paths of devices whose events are being dropped until SYN_REPORT
        self.pad = None            # virtual Xbox pad (gamepad mode only)
        self.pad_ff = {}           # virtual effect id -> physical effect id
        self.bt = None             # socket to rg35xxh-btpad / -usbpad (external controller modes)
        self.ext = "bt"             # its transport, from the service's hello: "bt" | "usb" | "switch" | "switch-bt"
        self.ext_rumble_id = None   # effect id for vibration requested by the PC
        self.motor_timer = None     # motor gate (MOTOR_INTERVAL): pending updates, last update time
        self.motor_last = 0.0
        self.motor_pending_upload = {}
        self.motor_pending_play = {}
        self.motor_ext_want = self.motor_ext_applied = 0   # level 0..MOTOR_LEVELS
        self.motor_ext_ids = {}     # level -> effect id (wired mode, uploaded on first use)
        self.motor_game_endless = set()   # game effects that asked for endless length
        self.motor_game_active = set()    # ... currently playing (re-triggered)
        self.motor_refresh_timer = None
        self.bt_watch = None
        self.icon_mode = "desktop"  # mode whose icon the taskbar shows (lags during the shake)
        self.touch = None           # short-lived virtual touchscreen (pointer hiding)
        self.anim = None
        self.waybar_pid = None
        self.haptic_id = None
        self.step_ids = {}
        self.axis_offset = {}      # software centre correction per axis (set by re-centre)
        self.watches = {}          # fd -> GLib watch id
        self.ui = None              # display side (on-screen keyboard, touch target): own process, ui.py
        self.ui_watch = None
        self.ui_buf = b""
        self.ui_retry = None        # respawn timer after the UI process ended
        self.ui_backoff = 2         # s, doubled per failed start (no display after a log-out)
        self.osk_visible = False
        self.stick_feed = False     # Controls app's stick view open (_stick_feed_check)
        self.macro = None           # the macro being played (_macro_*)
        self.rec_state = None       # macro recording: None | "armed" | "recording" | "paused"
        self.rec = None
        self.rec_req = None         # (name, pointer) from the Controls app
        self.rec_mtime = None
        self.ticks = 0
        # Auto-switch per app (_focus_*, _auto_check): the focused window from labwc, and the
        # profile linked to it (None = the hand-picked one)
        self.focus = None           # focus.FocusWatcher while connected
        self.focus_watch = None
        self.focus_retry_at = 0.0
        self.focus_app = None       # app_id of the focused window
        self.auto_profile = None
        self.links, self.links_stamp = {}, None
        for flag in ("rg35xxh-gamepad-mode", "rg35xxh-bt-mode", "rg35xxh-wired-mode", INPUTMODE_FRAME):
            set_flag(flag, False)
        self._open_devices()
        self._create_virtual_devices()
        self._ui_start()

    # ------------------------------------------------------------ devices
    def _open_devices(self, wait=15.0):
        deadline = time.monotonic() + wait
        found = {}
        while time.monotonic() < deadline:
            for path in evdev.list_devices():
                try:
                    d = evdev.InputDevice(path)
                except OSError:
                    continue
                # Match the built-in devices by name: USB/BT keyboards also report
                # KEY_VOLUMEUP / KEY_POWER and must not be grabbed.
                role = BUILTIN.get(d.name)
                if role and role not in found:
                    found[role] = d
                else:
                    d.close()
            if len(found) == len(BUILTIN):
                break
            time.sleep(0.5)
        # Only a device we hold exclusively is used. One whose grab fails is closed: kept, it
        # would be set up as the gamepad (motor included) without its input ever being read
        # (codebase audit 2026-10-30, M07). Without the gamepad the daemon is useless, so that
        # case ends the start-up and the session's restart loop tries again.
        owned = {}
        for role, d in found.items():
            for attempt in range(1, GRAB_TRIES + 1):
                try:
                    d.grab()
                    break
                except OSError as e:
                    log.warning("cannot grab %s (%s), try %d/%d: %s", role, d.path, attempt, GRAB_TRIES, e)
                    if attempt < GRAB_TRIES:
                        time.sleep(GRAB_RETRY_S)
            else:
                d.close()
                if role == "gamepad":
                    for other in found.values():
                        if other is not d and other not in owned.values():
                            other.close()
                    raise RuntimeError(f"cannot grab the gamepad ({d.path}); restarting")
                log.error("%s (%s) not used: cannot grab it", role, d.path)
                continue
            log.info("%s: %s (%s)", role, d.name, d.path)
            owned[role] = d
            self.devices.append(d)
        self.gamepad = owned.get("gamepad")
        if not self.gamepad:
            log.error("gamepad '%s' not found", GAMEPAD_NAME)
        else:
            self._setup_gamepad()
        for d in self.devices:
            self._watch(d)

    def _watch(self, d):
        self.watches[d.fd] = GLib.io_add_watch(d.fd, GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR,
                                               self._on_device, d)

    def _setup_gamepad(self):
        self.absinfo = {}
        for code, info in self.gamepad.capabilities().get(E.EV_ABS, []):
            self.absinfo[code] = info
        self.haptic_id = None
        self.step_ids = {}     # (magnitude, ms) -> uploaded effect id, for SPRING_PULSES
        self.haptic_scale = self.core.s["haptic_strength"]
        if E.EV_FF in self.gamepad.capabilities():
            try:
                self.haptic_id = self._upload_rumble(0xFFFF, 450)   # shutdown, re-centre
                for strength in SPRING_PULSES:
                    mag = self._magnitude(strength)
                    if mag and (mag, SPRING_PULSE_MS) not in self.step_ids:
                        self.step_ids[(mag, SPRING_PULSE_MS)] = self._upload_rumble(mag, SPRING_PULSE_MS)
            except OSError as e:
                log.warning("rumble not available: %s", e)

    def _release_effects(self):
        """Motor first: stop every vibration effect on the gamepad, then erase it (Handtop's own
        haptics, the PC's levels, the games' effects) and forget the ids. Called before the
        gamepad is closed (clean exit, stick re-centre), so nothing is left to the kernel's
        teardown while it may still be playing (docs/hardware-safety.md, rule 2). Safe on a
        half-built daemon. The motor gate's state is reset too; the PC's wanted level is kept
        (re-applied on its next request)."""
        for name in ("motor_timer", "motor_refresh_timer"):
            tid = getattr(self, name, None)
            if tid:
                GLib.source_remove(tid)
                setattr(self, name, None)
        for name in ("motor_game_active", "motor_game_endless", "motor_pending_upload", "motor_pending_play"):
            if getattr(self, name, None) is not None:
                getattr(self, name).clear()
        g = getattr(self, "gamepad", None)
        ids = [i for i in [getattr(self, "haptic_id", None), *getattr(self, "step_ids", {}).values(),
                           *getattr(self, "motor_ext_ids", {}).values(), *getattr(self, "pad_ff", {}).values()]
               if i is not None]
        if g is not None and ids:
            for eid in ids:
                try:
                    g.write(E.EV_FF, eid, 0)
                except OSError as e:
                    log.debug("stop effect %d: %s", eid, e)
            time.sleep(0.05)
            for eid in ids:
                try:
                    g.erase_effect(eid)
                except OSError as e:
                    log.debug("erase effect %d: %s", eid, e)
        self.haptic_id = None
        self.step_ids = {}
        self.motor_ext_ids = {}
        self.motor_ext_applied = 0
        self.pad_ff = {}

    def _magnitude(self, strength):
        scale = max(0.0, min(1.0, self.core.s["haptic_strength"]))
        return int(round(strength * scale * 0xFFFF))

    def _upload_rumble(self, magnitude, ms):
        rumble = ff.Rumble(strong_magnitude=magnitude, weak_magnitude=magnitude)
        eff = ff.Effect(E.FF_RUMBLE, -1, 0, ff.Trigger(0, 0), ff.Replay(ms, 0),
                        ff.EffectType(ff_rumble_effect=rumble))
        return self.gamepad.upload_effect(eff)

    # ---------------------------------------------------- stick re-centre
    # The stick driver (rocknix-singleadc-joypad) measures each axis' centre ONCE, from a single
    # ADC reading, when the device is first opened; a bad reading leaves a stick drifting until
    # the device is reopened. We are the only user of the device, so closing and reopening it
    # makes the driver measure the centre again. Any axis still off-centre afterwards gets a
    # software correction. Triggered by SIGUSR1 (the "Re-center sticks" app).
    RECENTER_THRESHOLD = 0.08      # fraction of full travel still counted as "off-centre"

    def _recenter(self):
        g = self.gamepad
        if g is None:
            spawn("notify-send", "-t", "4000", "Re-center sticks", "Gamepad not found")
            return True
        log.info("re-centre: reopening %s", g.path)
        path = g.path
        self._release_effects()    # effects live on this file handle: stop + erase them first
        wid = self.watches.pop(g.fd, None)
        if wid:
            GLib.source_remove(wid)
        try:
            g.ungrab()
        except OSError:
            pass
        g.close()
        self.devices.remove(g)
        self.gamepad = None
        time.sleep(0.2)
        try:
            g = evdev.InputDevice(path)
            g.grab()
        except OSError as e:
            log.error("re-centre: cannot reopen %s: %s; restarting", path, e)
            GLib.idle_add(self._quit)
            return True
        self.gamepad = g
        self.devices.append(g)
        self._setup_gamepad()
        self._watch(g)
        if self.motor_ext_want:           # the PC still wants vibration (Wired / BT): re-apply it
            self._motor_kick()

        # Verify: sample the axes for ~0.5 s and correct what is still off-centre.
        samples = {code: [] for code in HW_AXES}
        for _ in range(10):
            time.sleep(0.05)
            for code in HW_AXES:
                samples[code].append(g.absinfo(code).value)
        self.axis_offset = {}
        report = []
        for code, vals in samples.items():
            info = self.absinfo.get(code)
            if not info or info.max == info.min:
                continue
            half = (info.max - info.min) / 2.0
            avg = sum(vals) / len(vals)
            steady = (max(vals) - min(vals)) <= 2 * max(info.fuzz, 1) + 8
            if steady and abs(avg) > self.RECENTER_THRESHOLD * half:
                self.axis_offset[code] = int(round(avg))
            report.append("%s %+d%%" % (HW_AXES[code], round(100 * avg / half)))
        now = time.monotonic()
        for name in HW_AXES.values():
            self._run(self.core.axis(name, 0.0, now))
        log.info("re-centre: driver centre re-measured; rest %s; software offsets %s",
                 ", ".join(report), self.axis_offset or "none")
        self._haptic()
        msg = "Sticks re-centered." + (" Correction applied to " + ", ".join(HW_AXES[c] for c in self.axis_offset)
                                       if self.axis_offset else "")
        spawn("notify-send", "-t", "4000", "Re-center sticks", msg)
        return True

    def _create_virtual_devices(self):
        self.mouse = evdev.UInput({
            E.EV_KEY: [E.BTN_LEFT, E.BTN_RIGHT, E.BTN_MIDDLE, E.BTN_SIDE, E.BTN_EXTRA],   # side/extra: back/forward
            E.EV_REL: [E.REL_X, E.REL_Y, E.REL_WHEEL, E.REL_HWHEEL, E.REL_WHEEL_HI_RES, E.REL_HWHEEL_HI_RES],
        }, name="rg35xxh virtual mouse")
        # No power/sleep keys: logind would otherwise watch this device for them.
        keys = [k for k in range(1, 249) if k not in (E.KEY_POWER, E.KEY_SLEEP, E.KEY_SUSPEND, E.KEY_WAKEUP)]
        self.keyboard = evdev.UInput({E.EV_KEY: keys}, name="rg35xxh virtual keyboard")

    def _create_pad(self):
        caps = {
            E.EV_KEY: [E.BTN_A, E.BTN_B, E.BTN_X, E.BTN_Y, E.BTN_TL, E.BTN_TR, E.BTN_SELECT,
                       E.BTN_START, E.BTN_MODE, E.BTN_THUMBL, E.BTN_THUMBR],
            E.EV_ABS: [(c, evdev.AbsInfo(0, -32768, 32767, 16, 128, 0)) for c in (E.ABS_X, E.ABS_Y, E.ABS_RX, E.ABS_RY)]
            + [(c, evdev.AbsInfo(0, 0, 255, 0, 0, 0)) for c in (E.ABS_Z, E.ABS_RZ)]
            + [(c, evdev.AbsInfo(0, -1, 1, 0, 0, 0)) for c in (E.ABS_HAT0X, E.ABS_HAT0Y)],
            E.EV_FF: [E.FF_RUMBLE],
        }
        # Identify as an Xbox 360 controller so SDL/Moonlight use the standard mapping.
        self.pad = evdev.UInput(caps, name="Microsoft X-Box 360 pad", vendor=0x045E, product=0x028E,
                                version=0x110, bustype=E.BUS_USB, max_effects=16)
        self.pad_ff = {}
        self.pad_watch = GLib.io_add_watch(self.pad.fd, GLib.IO_IN, self._on_pad_fd)
        log.info("gamepad mode: virtual Xbox pad created")

    def _destroy_pad(self):
        if self.pad:
            GLib.source_remove(self.pad_watch)
            phys_ids = list(self.pad_ff.values())
            for phys in phys_ids:                  # stop first, then erase (motor first)
                try:
                    self.gamepad.write(E.EV_FF, phys, 0)
                except (OSError, AttributeError):
                    pass
            for phys in phys_ids:
                try:
                    self.gamepad.erase_effect(phys)
                except (OSError, AttributeError):
                    pass
            self.pad_ff = {}
            self.motor_game_active.clear()
            self.motor_game_endless.clear()
            # A game's upload or play still waiting for the motor gate must not reach the motor
            # after the mode ended: it would upload a new effect, play it, and stay on the
            # gamepad with nothing left to erase it (codebase audit 2026-10-30, M02).
            self.motor_pending_upload.clear()
            self.motor_pending_play.clear()
            self.pad.close()
            self.pad = None
            log.info("desktop mode: virtual pad removed")

    # ------------------------------------------- display side (ui.py, own process)
    # The daemon itself never connects to the display: GDK ends a process with _exit() when its
    # Wayland display goes away (every log-out), which would skip the clean exit. The on-screen
    # keyboard and the touch target live in a child process instead (JSON lines over its
    # stdin/stdout); it is restarted if it ends, and ends by itself when the daemon does.
    def _ui_start(self):
        self.ui_retry = None
        if not os.environ.get("WAYLAND_DISPLAY"):
            log.warning("no WAYLAND_DISPLAY: on-screen keyboard unavailable")
            return False
        try:
            self.ui = subprocess.Popen(
                [sys.executable, "-m", "rg35xxh_inputd.ui", json.dumps(self.core.bind)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE)   # stderr: same log as ours
        except OSError as e:
            log.warning("cannot start the on-screen keyboard process: %s", e)
            self._ui_schedule()
            return False
        os.set_blocking(self.ui.stdin.fileno(), False)   # a stuck UI must never block input
        self.ui_buf = b""
        self.ui_watch = GLib.io_add_watch(self.ui.stdout.fileno(), GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR,
                                          self._on_ui)
        return False

    def _ui_schedule(self):
        if self.ui_retry is None:
            self.ui_retry = GLib.timeout_add(int(self.ui_backoff * 1000), self._ui_start)
            self.ui_backoff = min(self.ui_backoff * 2, 60)

    def _ui_send(self, *cmd):
        if self.ui is None:
            return
        try:
            os.write(self.ui.stdin.fileno(), (json.dumps(cmd) + "\n").encode())
        except BlockingIOError:
            log.warning("on-screen keyboard process not reading: dropped %s", cmd[:2])
        except OSError:
            pass                            # it ended: _on_ui sees the hang-up

    def _on_ui(self, fd, cond):
        try:
            data = os.read(fd, 65536)
        except OSError:
            data = b""
        if not data:
            self._ui_stop("ended")
            self._ui_schedule()
            return False
        self.ui_buf += data
        while b"\n" in self.ui_buf:
            line, self.ui_buf = self.ui_buf.split(b"\n", 1)
            try:
                kind, *args = json.loads(line)
                if kind == "ready":
                    self.ui_backoff = 2
                    log.info("on-screen keyboard process ready (pid %d)", self.ui.pid)
                elif kind == "visible":
                    self.osk_visible = bool(args[0])
                    self.core.set_osk_visible(self.osk_visible)
                elif kind == "type":
                    self._type_combo(args[0], args[1])
                    if self.rec_state == "recording":     # typed on the on-screen keyboard
                        now = time.monotonic()
                        for m in args[0]:
                            self._rec_event(now, ("down", m))
                        self._rec_event(now, ("key", args[1]))
                        for m in reversed(args[0]):
                            self._rec_event(now, ("up", m))
            except Exception as e:          # bad line or unknown key: ignore it
                log.warning("on-screen keyboard process: %r: %s", line[:80], e)
        return True

    def _ui_stop(self, why):
        """Stop the UI process (if still running) and forget it."""
        ui, self.ui = self.ui, None
        if self.ui_watch:
            GLib.source_remove(self.ui_watch)
            self.ui_watch = None
        if self.osk_visible:
            self.osk_visible = False
            self.core.set_osk_visible(False)
        if ui is None:
            return
        for f in (ui.stdin, ui.stdout):
            try:
                f.close()                   # stdin EOF: the UI process exits by itself
            except OSError:
                pass
        try:
            ui.wait(timeout=1)
        except subprocess.TimeoutExpired:
            ui.terminate()
            try:
                ui.wait(timeout=1)
            except subprocess.TimeoutExpired:
                ui.kill()
                ui.wait()
        log.info("on-screen keyboard process %s (exit %s)", why, ui.returncode)

    # Key and mouse button ownership: a key can be held by more than one thing at once (L2 bound
    # to Ctrl while a macro taps Ctrl + C, a copy binding pressed while Ctrl is held). Each press
    # and release is counted per key; the virtual device sees the key go down at the first press
    # and up at the last release, so a macro's tap never lets go of a key a button still holds.
    def _owned(self):
        if "owners" not in self.__dict__:
            self.owners = {}                       # "KEY_X" / "BTN_LEFT" -> presses not released
        return self.owners

    def _key_out(self, dev, name, down):
        """Press / release name on dev (keyboard or mouse) under the ownership count. True if an
        event was written (the caller sends the syn)."""
        code = getattr(E, name, None) if name.startswith(("KEY_", "BTN_")) else None
        if not isinstance(code, int):
            log.warning("unknown key %r (ignored)", name)
            return False
        owners = self._owned()
        n = owners.get(name, 0)
        if down:
            owners[name] = n + 1
            if n:
                return False                       # already down for someone else
        else:
            if n > 1:
                owners[name] = n - 1
                return False                       # someone else still holds it
            owners.pop(name, None)
        dev.write(E.EV_KEY, code, 1 if down else 0)
        return True

    def _release_owned(self):
        """Let go of every key and button still counted as held (mode switch, exit): nothing may
        stay down on the virtual devices whatever lost track of it."""
        owners = self._owned()
        keys = [k for k in owners if k.startswith("KEY_")]
        btns = [k for k in owners if k.startswith("BTN_")]
        owners.clear()
        if keys and getattr(self, "keyboard", None):
            for k in keys:
                self.keyboard.write(E.EV_KEY, getattr(E, k), 0)
            self.keyboard.syn()
        if btns and getattr(self, "mouse", None):
            for b in btns:
                self.mouse.write(E.EV_KEY, getattr(E, b), 0)
            self.mouse.syn()

    def _type_combo(self, mods, key):
        for m in mods:
            self._key_out(self.keyboard, m, True)
        self._key_out(self.keyboard, key, True)
        self.keyboard.syn()
        self._key_out(self.keyboard, key, False)
        for m in reversed(mods):
            self._key_out(self.keyboard, m, False)
        self.keyboard.syn()

    # ------------------------------------------------------------- events
    # GLib drops a callback that raises: its timer or watch is gone for good while the rest of
    # the main loop, the heartbeat included, keeps running, so the watchdog never restarts the
    # daemon and buttons or the pointer stay dead. The two input callbacks therefore log the
    # error and end the daemon; the session's restart loop starts a fresh one 2 s later
    # (codebase audit 2026-10-30, M05).
    def _input_failed(self, where):
        log.exception("%s failed; exiting so that a fresh daemon starts", where)
        GLib.idle_add(self._quit)
        return False

    def _on_device(self, fd, cond, dev):
        try:
            return self._on_device_events(cond, dev)
        except Exception:
            return self._input_failed(f"input from {dev.path}")

    def _on_device_events(self, cond, dev):
        if cond & (GLib.IO_HUP | GLib.IO_ERR):
            # Built-in devices can be re-created (e.g. after resume): exit and let the
            # session's restart loop start a fresh daemon that opens them again.
            log.error("device lost: %s (%s), restarting", dev.path, dev.name)
            GLib.idle_add(self._quit)
            return False
        now = time.monotonic()
        try:
            for ev in dev.read():
                # SYN_DROPPED: the kernel's event queue for this device overflowed (the main
                # loop was busy) and events were lost, possibly a button release or a stick
                # returning to the centre. Skip everything up to the next SYN_REPORT, then
                # read the device's real state (codebase audit 2026-10-30, M06; the kernel's
                # input event-codes documentation asks for exactly this).
                if ev.type == E.EV_SYN and ev.code == E.SYN_DROPPED:
                    self.dropped.add(dev.path)
                    continue
                if dev.path in self.dropped:
                    if ev.type == E.EV_SYN and ev.code == E.SYN_REPORT:
                        self.dropped.discard(dev.path)
                        self._resync(dev, now)
                    continue
                if ev.type == E.EV_KEY and ev.value in (0, 1):
                    log.debug("key 0x%x %s -> %s", ev.code, "down" if ev.value else "up",
                              HW_BUTTONS.get(ev.code))
                if ev.type == E.EV_KEY and ev.code in HW_BUTTONS and ev.value in (0, 1):
                    self._run(self.core.button(HW_BUTTONS[ev.code], ev.value == 1, now))
                elif ev.type == E.EV_ABS and ev.code in HW_AXES:
                    self._run(self.core.axis(HW_AXES[ev.code], self._norm(ev.code, ev.value), now))
        except BlockingIOError:
            pass
        except OSError as e:
            log.error("read error on %s: %s", dev.path, e)
        return True

    def _resync(self, dev, now):
        """Bring the core in line with what dev reports now: buttons that changed while events
        were dropped are pressed or released, and the sticks get their current position."""
        down = set(dev.active_keys())
        keys = set(dev.capabilities().get(E.EV_KEY, []))
        changed = []
        for code, name in HW_BUTTONS.items():
            if code in keys and (code in down) != (name in self.core.held):
                changed.append(name)
                self._run(self.core.button(name, code in down, now))
        if self.gamepad is not None and dev.path == self.gamepad.path:
            for code, name in HW_AXES.items():
                if code in self.absinfo:
                    self._run(self.core.axis(name, self._norm(code, dev.absinfo(code).value), now))
        log.warning("input events dropped on %s; state read again (changed: %s)",
                    dev.path, ", ".join(changed) or "no buttons")

    def _norm(self, code, value):
        info = self.absinfo.get(code)
        if not info or info.max == info.min:
            return 0.0
        value -= self.axis_offset.get(code, 0)
        mid = (info.max + info.min) / 2.0
        v = (value - mid) / ((info.max - info.min) / 2.0)
        if self.hw.get("invert_" + HW_AXES[code]):
            v = -v
        return v

    def _tick(self):
        try:
            return self._tick_body()
        except Exception:
            return self._input_failed("input loop")

    def _screen_off_flag(self):
        """(screen off, from the Music app): the flag rg35xxh-screen-off writes; its first line is
        "music" when music keeps playing (Vol then still sets the volume)."""
        try:
            with open(runtime_flag("rg35xxh-screen-off"), "rb") as f:
                return True, f.read(16).split(b"\n", 1)[0].strip() == b"music"
        except FileNotFoundError:
            return False, False
        except OSError:
            return True, False

    def _tick_body(self):
        self.ticks += 1
        now = time.monotonic()
        if self.ticks % 10 == 0:
            self.core.set_screen_off(*self._screen_off_flag())
            self._layout_reload()
            self._config_reload()          # before the requests: a preview plays the new strength
            self._haptic_requests()
            self._haptic_preview()
            self._stick_feed_check()
            self._rec_check()
            self.core.set_osk_visible(self.osk_visible)
            self._focus_check(now)
        if self.stick_feed and self.ticks % STICK_FEED_TICKS == 0:
            self._stick_feed_write()
        self._run(self.core.tick(now))
        return True

    def _config_reload(self):
        """Settings layers (config.py) changed: read them again and hand them to the core. Runs in
        the 100 ms housekeeping; costs a few stat() calls when nothing changed. An expired trial
        file ("Keep these controls?" not answered in time) is deleted here, by the daemon, so the
        change is undone even if the Controls app is gone."""
        auto = getattr(self, "auto_profile", None)
        st = config.stamp(auto)
        until = getattr(self, "trial_until", None)
        if st == self.cfg_stamp and not (until is not None and config.trial_clock() >= until):

            if self.haptic_scale != self.core.s["haptic_strength"]:
                self._haptics_rescale()
            return
        self.cfg_stamp = st
        cfg = config.load_layers(profile=auto)
        self.trial_until = cfg.trial_until
        self.app_settings = cfg.app_settings
        if cfg.trial_expired:
            try:
                os.unlink(config.trial_path())
                log.info("controls: trial ended without Keep, change undone")
            except OSError:
                pass
            self.cfg_stamp = config.stamp(auto)
        old = ({"settings." + k: v for k, v in self.core.s.items()}, {"desktop." + k: v for k, v in self.core.bind.items()},
               {"hardware." + k: v for k, v in self.hw.items()})
        self.hw = cfg.hardware
        old_bind = dict(self.core.bind)
        self._run(self.core.reconfigure(cfg.settings, cfg.bindings))
        new = ({"settings." + k: v for k, v in self.core.s.items()}, {"desktop." + k: v for k, v in self.core.bind.items()},
               {"hardware." + k: v for k, v in self.hw.items()})
        changed = [f"{k} {o.get(k)} -> {n.get(k)}" for o, n in zip(old, new)
                   for k in list(n) + [k for k in o if k not in n] if o.get(k) != n.get(k)]

        log.info("controls: %s", ", ".join(changed) if changed else "no change")
        if self.core.bind != old_bind and getattr(self, "ui", None):
            self._ui_send("bindings", "set", self.core.bind)   # keyboard badges
        self.core.pointer_scale = self.layout.scale(self.core.s["display_speed_scale"])
        if self.haptic_scale != self.core.s["haptic_strength"]:
            self._haptics_rescale()

    # ------------------------------------------------ auto-switch per app
    # labwc reports every window and which one has the focus (focus.py). A profile linked to the
    # focused app in apps.json (Controls app) replaces the hand-picked one while that app is in
    # front. The switch waits while a button is held or a macro runs (a drag, Alt held through
    # Alt+Tab), and for the whole External Controller session (the PC must not see the handheld
    # change mid-game); both are retried every 100 ms housekeeping.
    FOCUS_RETRY_S = 5.0
    WINDOWS_FILE = "rg35xxh-controls-windows.json"   # open windows, for the Controls app's picker

    def _focus_check(self, now):
        if self.focus is None and now >= self.focus_retry_at:
            self._focus_connect(now)
        self._auto_check()

    def _focus_connect(self, now):
        try:
            self.focus = focus.FocusWatcher()
        except OSError as e:
            if not self.focus_retry_at:
                log.info("focus watcher: no display yet (%s), retrying every %.0f s", e, self.FOCUS_RETRY_S)
            self.focus_retry_at = now + self.FOCUS_RETRY_S
            return
        self.focus_watch = GLib.io_add_watch(self.focus.fileno(), GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR,
                                             self._on_focus)
        log.info("focus watcher: connected")

    def _focus_lost(self, why):
        log.warning("focus watcher: %s; reconnecting in %.0f s", why, self.FOCUS_RETRY_S)
        if self.focus_watch:
            GLib.source_remove(self.focus_watch)
        self.focus_watch = None
        if self.focus is not None:
            self.focus.close()
        self.focus = None
        self.focus_app = None
        self.focus_retry_at = time.monotonic() + self.FOCUS_RETRY_S
        self._focus_publish()

    def _on_focus(self, _fd, _cond):
        try:
            changed = self.focus.read()
        except (OSError, focus.ProtocolError) as e:
            self._focus_lost(e)
            return False
        if changed:
            self.focus_app = self.focus.focused()
            self._auto_check()
            self._focus_publish()
        return True

    def _focus_publish(self):
        """Open windows + the focused app + the auto-switched profile, for the Controls app."""
        fw = getattr(self, "focus", None)
        data = {"windows": fw.open_windows() if fw else [], "focused": self.focus_app,
                "auto": self.auto_profile, "connected": fw is not None}
        path = runtime_flag(self.WINDOWS_FILE)
        try:
            with open(path + ".tmp", "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(path + ".tmp", path)
        except OSError as e:
            log.debug("windows file: %s", e)

    def _links_now(self):
        """apps.json, read again only when it changed (stat per housekeeping)."""
        path = config.apps_file()
        try:
            st = os.stat(path)
            key = (st.st_ino, st.st_mtime_ns, st.st_size)
        except OSError:
            key = None
        if key != self.links_stamp:
            self.links_stamp = key
            self.links = config.read_links(path) if key else {}
        return self.links

    def _auto_check(self):
        wanted = config.linked_profile(self._links_now(), self.focus_app)
        if wanted == self.auto_profile:
            return
        if self.bt or self.core.held or self.macro:
            return                          # retried at the next housekeeping
        before = self.auto_profile or config.active_profile()
        self.auto_profile = wanted
        after = wanted or config.active_profile()
        log.info("controls: %s in front: profile %s%s", self.focus_app or "no window", after,
                 "" if wanted else " (hand-picked)")
        self._config_reload()
        self._focus_publish()
        if after != before and getattr(self, "app_settings", True) and getattr(self, "trial_until", None) is None:
            self._notify("profile", "Controls", "Profile: " + ("Default" if after == config.DEFAULT_PROFILE else after),
                         2000)

    def _haptics_rescale(self):
        """haptic_strength changed: the mode-change pulses (step_ids) were uploaded at the old
        strength. Replace them with the motor idle, the way the stick re-centre re-uploads its
        effects: only Handtop's own pulses, never while they may play (feedback running) or in
        gamepad mode (games and PCs use the motor there); retried at the next housekeeping."""
        if self.gamepad is None or self.anim or getattr(self, "preview", None) is not None \
                or self.core.mode != "desktop":
            return
        now = time.monotonic()
        if now - getattr(self, "haptic_rescaled_at", -1.0) < HAPTIC_RESCALE_MIN_S:
            return                         # a slider being dragged: at most one re-upload per 0.3 s
        self.haptic_rescaled_at = now
        new = self.core.s["haptic_strength"]
        old_ids = list(self.step_ids.values())
        for eid in old_ids:
            try:
                self.gamepad.write(E.EV_FF, eid, 0)
            except OSError as e:
                log.debug("stop effect %d: %s", eid, e)
        if old_ids:
            time.sleep(0.05)               # as _release_effects: stop, let it settle, then erase
        for eid in old_ids:
            try:
                self.gamepad.erase_effect(eid)
            except OSError as e:
                log.debug("erase effect %d: %s", eid, e)
        self.step_ids = {}
        self.haptic_scale = new
        try:
            for strength in SPRING_PULSES:
                mag = self._magnitude(strength)
                if mag and (mag, SPRING_PULSE_MS) not in self.step_ids:
                    self.step_ids[(mag, SPRING_PULSE_MS)] = self._upload_rumble(mag, SPRING_PULSE_MS)
        except OSError as e:
            log.warning("mode-change vibration not available: %s", e)
        log.info("controls: mode-change vibration at %.2f", new)

    def _layout_reload(self):
        """Screen layout for per-screen pointer speed: JSON written by rg35xxh-display on every
        layout change ([{"x","y","w","h","scale"}, ...]); none = handheld only, speed 1."""
        path = runtime_flag("rg35xxh-pointer-layout")
        try:
            mtime = os.stat(path).st_mtime
        except OSError:
            mtime = None
        if mtime == self.layout_mtime:
            return
        self.layout_mtime = mtime
        rects = []
        if mtime is not None:
            try:
                import json
                with open(path) as f:
                    rects = json.load(f)
            except (OSError, ValueError):
                rects = []
            if not rects and self.layout.rects:
                # A layout file with no screens is a glitch (rg35xxh-display no longer writes one;
                # v0.3.8 did when wlr-randr returned nothing, and the pointer crawled on a big
                # monitor at x1, 2026-11-06): keep the current speed.
                log.info("screen layout for pointer speed: empty layout ignored, keeping x%.2f",
                         self.core.pointer_scale)
                return
        self.layout.set_rects(rects)
        if len(self.layout.rects) > 1 and getattr(self, "mouse", None):
            # Two screens: start from a known point. A long move up-left ends in the layout's
            # top-left corner (the compositor clamps it), and the estimate starts there too.
            self.mouse.write(E.EV_REL, E.REL_X, -30000)
            self.mouse.write(E.EV_REL, E.REL_Y, -30000)
            self.mouse.syn()
            self.layout.x, self.layout.y = self.layout._closest(-30000, -30000)
        self.core.pointer_scale = self.layout.scale(self.core.s["display_speed_scale"])
        log.info("screen layout for pointer speed: %s -> x%.2f", rects, self.core.pointer_scale)

    # ------------------------------------------------------------ actions
    def _run(self, actions):
        mouse_dirty = False
        for a in actions:
            kind = a[0]
            if self.rec_state == "recording":
                self._rec_from_action(a)
            if kind == "rel":
                self.mouse.write(E.EV_REL, E.REL_X, a[1])
                self.mouse.write(E.EV_REL, E.REL_Y, a[2])
                mouse_dirty = True
                self.layout.move(a[1], a[2])
                self.core.pointer_scale = self.layout.scale(self.core.s["display_speed_scale"])
            elif kind == "wheel":
                if a[1]:
                    self.mouse.write(E.EV_REL, E.REL_WHEEL_HI_RES, a[1])
                    self._wheel_notch(E.REL_WHEEL, a[1], 0)
                if a[2]:
                    self.mouse.write(E.EV_REL, E.REL_HWHEEL_HI_RES, a[2])
                    self._wheel_notch(E.REL_HWHEEL, a[2], 1)
                mouse_dirty = True
            elif kind == "mouse":
                btn = {"left": "BTN_LEFT", "right": "BTN_RIGHT", "middle": "BTN_MIDDLE",
                       "back": "BTN_SIDE", "forward": "BTN_EXTRA"}[a[1]]
                mouse_dirty |= self._key_out(self.mouse, btn, a[2])
            elif kind == "key":
                if self._key_out(self.keyboard, a[1], a[2]):
                    self.keyboard.syn()
                if self.osk_visible:                    # L1 / R1 / R2: show it on the keyboard too
                    self._ui_send("osk", "key_state", a[1], a[2])
            elif kind == "clipboard":
                self._clipboard(a[1])
            elif kind == "launch":
                self._launch(a[1])
            elif kind == "macro":
                self._macro_toggle(a[1])
            elif kind == "macro_record":
                self._rec_toggle()
            elif kind == "osk" and not self.ui:
                log.warning("on-screen keyboard requested but unavailable")
            elif kind == "osk":
                if a[1] == "toggle":
                    self._ui_send("osk", "toggle")
                    self.osk_visible = not self.osk_visible     # the UI process confirms it
                    self.core.set_osk_visible(self.osk_visible)
                    log.info("on-screen keyboard %s", "shown" if self.osk_visible else "hidden")
                elif a[1] == "move":
                    self._ui_send("osk", "move", a[2], a[3])
                elif a[1] in ("press", "release", "repeat", "shift"):
                    self._ui_send("osk", a[1])
            elif kind == "mode":
                if a[1] == "gamepad":
                    self._macro_stop("gamepad mode")          # nothing a macro holds stays down
                    self._release_owned()                     # ... nor anything else
                    if self.osk_visible:
                        self._ui_send("osk", "hide")
                        self.osk_visible = False
                        self.core.set_osk_visible(False)
                    self._hide_cursor()                   # no pointer outside desktop mode
                    if self.bt:
                        flag, title, text, _icon = EXT_MODES[self.ext]
                        set_flag(flag, True)
                        spawn("notify-send", "-t", "6000", title, text)
                    else:
                        self._create_pad()
                        set_flag("rg35xxh-gamepad-mode", True)
                        spawn("notify-send", "-t", "2500", "Gamepad mode", "Hold Start for 1 s to return to desktop mode")
                else:
                    if self.bt:
                        title = EXT_MODES[self.ext][1]
                        self._bt_close()
                        spawn("notify-send", "-t", "2500", "Desktop mode", f"{title} stopped")
                    else:
                        self._destroy_pad()
                        spawn("notify-send", "-t", "1500", "Desktop mode")
                    set_flag("rg35xxh-gamepad-mode", False)
                self._mode_feedback(EXT_MODES[self.ext][3] if self.bt else a[1])   # icon shake + haptic wobble
            elif kind in ("pad_key", "pad_abs"):
                etype = E.EV_KEY if kind == "pad_key" else E.EV_ABS
                if self.bt:
                    self._bt_send(etype, E.ecodes[a[1]], a[2])
                elif self.pad:
                    self.pad.write(etype, E.ecodes[a[1]], a[2])
                    self.pad.syn()
            elif kind == "cmd":
                self._command(a[1])
            elif kind == "screen_wake":
                spawn("rg35xxh-screen-on")
                self._idle_nudge()
            elif kind == "shutdown":
                self._shutdown()
        if mouse_dirty:
            self.mouse.syn()

    def _idle_nudge(self):
        """The press that wakes the screen is swallowed, so the compositor sees no input and
        swayidle's timers (auto-sleep, the Music app's screen off) would not start again until
        the next one. One pixel there and back is input to it, and invisible."""
        try:
            for dx in (1, -1):
                self.mouse.write(E.EV_REL, E.REL_X, dx)
                self.mouse.syn()
        except (OSError, AttributeError):
            pass

    def _wheel_notch(self, code, hires, idx):
        # Legacy wheel events for apps without hi-res support: one per 120 units.
        acc = getattr(self, "_notch_acc", [0, 0])
        acc[idx] += hires
        notches = int(acc[idx] / 120)
        if notches:
            acc[idx] -= notches * 120
            self.mouse.write(E.EV_REL, code, notches)
        self._notch_acc = acc

    def _launch(self, app_id):
        """launch:<desktop id> binding: start that app like the app drawer does (gio launch on its
        .desktop file; first match in the user's, Handtop's and Debian's application folders)."""
        dirs = [os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "applications"),
                "/usr/local/share/applications", "/usr/share/applications"]
        path = next((os.path.join(d, app_id + ".desktop") for d in dirs
                     if os.path.isfile(os.path.join(d, app_id + ".desktop"))), None)
        if path is None:
            log.warning("launch: no app %r", app_id)
            spawn("notify-send", "-t", "3000", "Controls", f"No app named {app_id}")
            return
        log.info("launch: %s", path)
        spawn("gio", "launch", path)

    def _clipboard(self, what):
        letter = "KEY_C" if what == "copy" else "KEY_V"
        mods = ["KEY_LEFTCTRL"]
        if self._focused_is_terminal():
            mods.append("KEY_LEFTSHIFT")
        self._type_combo(mods, letter)

    def _focused_is_terminal(self):
        if getattr(self, "focus", None) is not None:      # the focus watcher already knows
            return (self.focus_app or "") in TERMINALS
        # One query: repeated app_id matches are OR-ed by wlrctl; state:active = focused window.
        if not shutil.which("wlrctl"):
            return False
        argv = ["wlrctl", "toplevel", "find"] + ["app_id:" + a for a in TERMINALS] + ["state:active"]
        try:
            return subprocess.run(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                  timeout=0.5).returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False

    def _command(self, name):
        if self.bt:                       # external controller mode: wake the status screen
            dark = os.path.exists(runtime_flag(EXT_DARK))
            try:
                with open(runtime_flag(EXT_WAKE), "w") as f:
                    f.write(f"{time.monotonic():.3f} {name}\n")
            except OSError as e:
                log.debug("wake: %s", e)
            if dark and name == "power_menu":
                return                    # Power on a dark screen only wakes it (tap again for the menu)
        if name == "power_menu":
            spawn("rg35xxh-power-menu")
        elif name in ("volume_up", "volume_down"):
            self._volume(+1 if name == "volume_up" else -1)
        elif name in ("brightness_up", "brightness_down"):
            self._brightness(+1 if name == "brightness_up" else -1)

    # Volume: wpctl takes tens of ms (up to its 1 s timeout when PipeWire is busy), too long for
    # the input loop. Steps are added up here and one worker thread applies them, as one wpctl
    # call for whatever piled up meanwhile (20 "do volume_up" in a macro: one or two calls).
    VOLUME_STEP = 5                 # percent per step
    _vol_lock = threading.Lock()
    _vol_net = 0                    # steps not applied yet (+ up, - down)
    _vol_busy = False               # the worker thread is running

    def _volume(self, steps):
        with self._vol_lock:
            Daemon._vol_net += steps
            start = not Daemon._vol_busy
            Daemon._vol_busy = True
        if start:
            threading.Thread(target=self._volume_worker, name="volume", daemon=True).start()

    def _volume_worker(self):
        while True:
            with self._vol_lock:
                n = Daemon._vol_net
                Daemon._vol_net = 0
                if n == 0:
                    Daemon._vol_busy = False
                    return
            step = f"{abs(n) * self.VOLUME_STEP}%{'+' if n > 0 else '-'}"
            try:
                subprocess.run(["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", step],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1)
                out = subprocess.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], capture_output=True,
                                     text=True, timeout=1).stdout       # "Volume: 0.55 [MUTED]"
                vol = round(float(out.split()[1]) * 100)
                self._osd(0 if "MUTED" in out else vol, "volume")
            except (OSError, subprocess.TimeoutExpired, ValueError, IndexError) as e:
                log.warning("volume: %s", e)


    BACKLIGHT = "/sys/class/backlight/backlight"
    BRIGHTNESS_MIN = 0.05      # never fully dark
    BRIGHTNESS_STEP = 0.10

    def _brightness(self, direction):
        try:
            with open(self.BACKLIGHT + "/max_brightness") as f:
                mx = int(f.read())
            with open(self.BACKLIGHT + "/brightness") as f:
                cur = int(f.read())
            new = cur + direction * round(mx * self.BRIGHTNESS_STEP)
            new = max(round(mx * self.BRIGHTNESS_MIN), min(mx, new))
            with open(self.BACKLIGHT + "/brightness", "w") as f:
                f.write(str(new))
            self._osd(round(new * 100 / mx), "brightness")
        except (OSError, ValueError) as e:
            log.warning("brightness: %s", e)

    def _osd(self, percent, style):
        """Show a volume/brightness bar: one wob per kind (wob 0.14 has no per-value styles),
        fed through $XDG_RUNTIME_DIR/wob-<kind>.sock, started by the session autostart."""
        path = runtime_flag(f"wob-{style}.sock")
        try:
            fd = os.open(path, os.O_WRONLY | os.O_NONBLOCK)
        except OSError:
            return  # no OSD running
        try:
            os.write(fd, f"{max(0, min(100, percent))}\n".encode())
        except OSError:
            pass
        finally:
            os.close(fd)

    def _shutdown(self):
        log.info("power held: shutting down")
        self._haptic()
        try:
            with open(os.path.join(STATUS_LED, "trigger"), "w") as f:
                f.write("timer")
        except OSError as e:
            log.warning("status LED: %s", e)
        spawn("notify-send", "-u", "critical", "-t", "10000", "Shutting down…")
        GLib.timeout_add(600, lambda: spawn("systemctl", "poweroff") or False)

    def _haptic_requests(self):
        """Other programs ask for a vibration by creating $XDG_RUNTIME_DIR/rg35xxh-haptic-request
        (e.g. rg35xxh-lowbattery): the motor has one owner, this daemon, and the request plays
        Handtop's own fixed-length buzz (docs/hardware-safety.md, rules 1 and 5)."""
        try:
            os.unlink(runtime_flag("rg35xxh-haptic-request"))
        except FileNotFoundError:
            return
        except OSError as e:
            log.warning("haptic request: %s", e)
            return
        log.info("haptic requested")
        self._haptic()

    # --------------------------------------------------------------- macros
    # Play: a "macro:<name>" binding (macros.py). Steps run from GLib timers, a few per 10 ms, and
    # go through _run like any button's actions; whatever the macro holds down is tracked and let
    # go at the end, on a stop (the same button again), on gamepad mode and on exit.
    MACRO_BATCH = 20                # steps (or typed characters) per 10 ms at most

    def _macro_toggle(self, name):
        if self.macro:
            was = self.macro["name"]
            self._macro_stop("stopped")
            if was == name:
                return
        if not macros.NAME_RE.match(name):
            return
        try:
            steps, problems = macros.load(name, config._known_key)
        except OSError:
            spawn("notify-send", "-t", "3000", "Controls", f"No macro named {name}")
            log.warning("macro %r: not found", name)
            return
        for p in problems:
            log.warning("macro %r: %s", name, p)
        if not steps:
            return
        log.info("macro %r: %d steps", name, len(steps))
        self._notify("macro", f"Running macro {name}", "Press its button again to stop it", 0)
        self.macro = {"name": name, "steps": steps, "i": 0, "keys": set(), "buttons": set(), "timer": None,
                      "text": None}
        self._macro_tick()

    MACRO_BUDGET = 0.008            # seconds of work per tick at most (the input loop shares it)

    def _macro_tick(self):
        """One GLib timer run of the macro. An error in a step stops the macro (letting go of what
        it holds) instead of escaping: GLib would drop the timer and leave keys down."""
        try:
            return self._macro_tick_steps()
        except Exception:
            log.exception("macro %r failed", (self.macro or {}).get("name"))
            if self.macro:
                self.macro["timer"] = None
                self._macro_stop("error")
            return False

    def _macro_tick_steps(self):
        m = self.macro
        if m is None:
            return False
        m["timer"] = None
        done = 0
        start = time.monotonic()
        while done < self.MACRO_BATCH and time.monotonic() - start < self.MACRO_BUDGET:
            if m["text"]:                                  # typing a text step, a few letters a tick
                ch, m["text"] = m["text"][0], m["text"][1:]
                k = macros.char_key(ch)
                if k:
                    self._type_combo(*k)
                done += 1
                continue
            if m["i"] >= len(m["steps"]):
                self._macro_stop(None)
                return False
            st = m["steps"][m["i"]]
            m["i"] += 1
            if st[0] == "wait":
                m["timer"] = GLib.timeout_add(max(10, int(st[1] * 1000)), self._macro_tick)
                return False
            self._macro_step(st)
            done += 1
        m["timer"] = GLib.timeout_add(10, self._macro_tick)
        return False

    def _macro_step(self, st):
        m, w = self.macro, st[0]
        if w == "key":
            self._run([("key", st[1], True), ("key", st[1], False)])
        elif w == "combo":
            ks = st[1].split("+")
            self._run([("key", k, True) for k in ks] + [("key", k, False) for k in reversed(ks)])
        elif w in ("down", "up"):
            (m["keys"].add if w == "down" else m["keys"].discard)(st[1])
            self._run([("key", st[1], w == "down")])
        elif w == "click":
            self._run([("mouse", st[1], True), ("mouse", st[1], False)])
        elif w in ("press", "release"):
            (m["buttons"].add if w == "press" else m["buttons"].discard)(st[1])
            self._run([("mouse", st[1], w == "press")])
        elif w == "text":
            m["text"] = st[1]
        elif w == "move":
            self._run([("rel", st[1], st[2])])
        elif w == "scroll":
            self._run([("wheel", st[1], st[2])])
        elif w == "launch":
            self._run([("launch", st[1])])
        elif w == "do":
            self._run(self.core._action(st[1], True))

    def _macro_stop(self, why):
        m = self.macro
        if m is None:
            return
        self.macro = None
        if m["timer"]:
            GLib.source_remove(m["timer"])
        rel = [("key", k, False) for k in m["keys"]] + [("mouse", b, False) for b in m["buttons"]]
        if rel and getattr(self, "keyboard", None):
            try:
                self._run(rel)
            except Exception:
                log.exception("macro %r: releasing its keys failed", m["name"])
        if why:
            log.info("macro %r: %s at step %d", m["name"], why, m["i"])
        self._notify("macro", f"Macro {m['name']} " + ("finished" if why is None else "stopped"),
                     "" if why is None else ("by its button" if why == "stopped" else why), 2500)

    # Record: the Controls app arms a recording ($XDG_RUNTIME_DIR/rg35xxh-macro-rec.json, {"cmd":
    # "arm", "name", "pointer"}), the "macro_record" button starts / pauses it from any app, and the
    # app's Stop ({"cmd": "stop"}) saves it as macros/<name>.macro ({"cmd": "cancel"}: discard).
    # The state is written to rg35xxh-macro-rec.status for the app.
    # Notifications that replace each other ("macro": running -> finished; "rec": its states). One
    # worker thread sends them in order with notify-send -p / -r, so a notification sent while the
    # previous one's id is not known yet still replaces it, and the main loop never waits.
    def _notify(self, key, title, body, ms):
        q = getattr(self, "note_q", None)
        if q is None:
            import queue
            q = self.note_q = queue.Queue()
            ids = {}

            def work():
                while True:
                    k, t, b, ms_ = q.get()
                    argv = ["notify-send", "-p", "-t", str(ms_)] + (["-r", str(ids[k])] if k in ids else []) + [t, b]
                    try:
                        out = subprocess.run(argv, capture_output=True, text=True, timeout=5,
                                             stdin=subprocess.DEVNULL).stdout.strip()
                        if out.isdigit():
                            ids[k] = int(out)
                    except (OSError, subprocess.SubprocessError) as e:
                        log.warning("notification: %s", e)
            threading.Thread(target=work, name="notify", daemon=True).start()
        q.put((key, title, body, ms))

    def _rec_check(self):
        path = runtime_flag("rg35xxh-macro-rec.json")
        try:
            mtime = os.stat(path).st_mtime_ns
        except OSError:
            mtime = None
        if mtime == self.rec_mtime:
            return
        self.rec_mtime = mtime
        if mtime is None:
            return
        try:
            with open(path) as f:
                req = json.load(f)
        except (OSError, ValueError):
            return
        cmd = req.get("cmd")
        if cmd == "arm" and macros.NAME_RE.match(str(req.get("name", ""))):
            self.rec_req = (req["name"], bool(req.get("pointer")))
            self.rec = macros.Recorder(self.rec_req[1], timing=bool(req.get("timing", True)))
            self.rec_state = "armed"
            log.info("macro recording armed: %r (pointer %s)", *self.rec_req)
        elif cmd in ("stop", "cancel") and self.rec_state:
            steps = self.rec.finish()
            name = self.rec_req[0]
            self.rec_state, self.rec = None, None
            if cmd == "stop" and steps:
                try:
                    macros.save(name, steps)
                    self._rec_status("saved", len(steps), name)
                    log.info("macro recording saved: %r, %d steps", name, len(steps))
                    return
                except (OSError, ValueError) as e:
                    log.warning("macro recording: %s", e)
            self._rec_status("empty" if cmd == "stop" else "cancelled", 0, name)
            return
        self._rec_status(self.rec_state, 0)

    def _rec_status(self, state, steps=None, name=None):
        data = {"state": state, "steps": len(self.rec.steps) if self.rec else (steps or 0),
                "name": name or (self.rec_req[0] if self.rec_req else None)}
        try:
            with open(runtime_flag("rg35xxh-macro-rec.status.tmp"), "w") as f:
                json.dump(data, f)
            os.replace(runtime_flag("rg35xxh-macro-rec.status.tmp"), runtime_flag("rg35xxh-macro-rec.status"))
        except OSError as e:
            log.warning("macro recording status: %s", e)

    def _rec_toggle(self):
        if self.rec_state is None:
            spawn("notify-send", "-t", "4000", "Macro recording",
                  "Start a recording in Controls > Advanced > Macros first")
            return
        if self.rec_state in ("armed", "paused"):
            self.rec.resume(time.monotonic())
            self.rec_state = "recording"
            self._notify("rec", "Recording macro", "Tap the record button to pause", 2500)
        else:
            self.rec_state = "paused"
            self._notify("rec", "Macro recording paused", "Tap again to go on, or stop it in Controls", 2500)
        log.info("macro recording: %s", self.rec_state)
        self._rec_status(self.rec_state)

    def _rec_event(self, t, step):
        if not self.rec.event(t, step):              # full
            self.rec_state = "paused"
            spawn("notify-send", "-t", "4000", "Macro recording paused", "Longest macro reached: stop it in Controls")
            self._rec_status("full")

    def _rec_from_action(self, a):
        t, kind = time.monotonic(), a[0]
        if kind == "key":
            self._rec_event(t, ("down" if a[2] else "up", a[1]))
        elif kind == "mouse":
            self._rec_event(t, ("press" if a[2] else "release", a[1]))
        elif kind == "rel":
            self._rec_event(t, ("move", a[1], a[2]))
        elif kind == "wheel":
            self._rec_event(t, ("scroll", a[1], a[2]))
        elif kind == "launch":
            self._rec_event(t, ("launch", a[1]))
        elif kind == "clipboard":
            self._rec_event(t, ("do", a[1]))
        elif kind == "cmd" and a[1] in macros.DO:
            self._rec_event(t, ("do", a[1]))
        elif kind == "osk" and a[1] == "toggle":
            self._rec_event(t, ("do", "osk_toggle"))

    def _stick_feed_check(self):
        """The Controls app's live stick view: while $XDG_RUNTIME_DIR/rg35xxh-controls-sticks.want
        is fresh (the app touches it every second; older than 2 s = the app is gone), write the
        sticks to rg35xxh-controls-sticks about 30 times a second. Nothing is written otherwise."""
        try:
            fresh = time.time() - os.stat(runtime_flag(STICK_WANT)).st_mtime < STICK_WANT_MAX_AGE
        except OSError:
            fresh = False
        if fresh != self.stick_feed:
            self.stick_feed = fresh
            log.info("stick view %s", "on" if fresh else "off")
            if not fresh:
                try:
                    os.unlink(runtime_flag(STICK_FEED))
                except OSError:
                    pass

    def _stick_feed_write(self):
        """One JSON line: the sticks as the pointer and scroll logic see them (-1..1 after the
        re-centre offset and axis inversion, y down = +), the dead zone and the mode. Written to a
        temporary file and renamed, so the app never reads half a line."""
        c = self.core
        data = {k: round(v, 3) for k, v in c.axes.items()}
        data.update(deadzone=c.s["deadzone"], mode=c.mode)
        path = runtime_flag(STICK_FEED)
        try:
            with open(path + ".tmp", "w") as f:
                f.write(json.dumps(data) + "\n")
            os.replace(path + ".tmp", path)
        except OSError as e:
            log.warning("stick view: %s", e)
            self.stick_feed = False

    def _haptic_preview(self):
        """The Controls app's vibration slider: $XDG_RUNTIME_DIR/rg35xxh-haptic-preview asks for the
        mode-change buzz at the current haptic_strength, so the user feels each value as it is set
        (it is how this buzz feels when switching modes). Plays once the pulses are re-uploaded at
        that strength, in desktop mode only, never over a running mode-change buzz; a request in
        gamepad mode is dropped (the motor belongs to the game there)."""
        try:
            os.unlink(runtime_flag("rg35xxh-haptic-preview"))
            self.preview_pending = True
        except FileNotFoundError:
            pass
        except OSError as e:
            log.warning("haptic preview: %s", e)
        if not getattr(self, "preview_pending", False):
            return
        if self.core.mode != "desktop":
            self.preview_pending = False
            log.info("haptic preview dropped: not in desktop mode")
            return
        if (self.anim or self.haptic_scale != self.core.s["haptic_strength"]
                or getattr(self, "preview", None) is not None):
            return                                     # rescale or a buzz still running: next tick
        self.preview_pending = False
        self.preview = 0
        self._preview_step()
        self.preview_timer = GLib.timeout_add(SPRING_STEP_MS, self._preview_step)

    def _preview_step(self):
        k = self.preview
        if k is None or k >= len(SPRING_PULSES) or self.core.mode != "desktop":
            self.preview = None
            return False
        eid = self.step_ids.get((self._magnitude(SPRING_PULSES[k]), SPRING_PULSE_MS))
        if eid is not None:
            self._play_effect(eid)
        self.preview = k + 1
        return True

    def _haptic(self):
        self._play_effect(self.haptic_id)

    def _play_effect(self, eid):
        if self.gamepad is not None and eid is not None:
            try:
                self.gamepad.write(E.EV_FF, eid, 1)
            except OSError as e:
                log.warning("rumble failed: %s", e)
        return False

    # ------------------------------------------------ pointer hiding
    def _hide_cursor(self):
        if self.touch:
            return
        if not self.ui:                     # no display side: cannot show the tap target
            return
        self._ui_send("target", "show")      # 2x2 px transparent overlay window, top-left corner
        caps = {E.EV_KEY: [E.BTN_TOUCH],
                E.EV_ABS: [(E.ABS_X, evdev.AbsInfo(0, 0, TOUCH_W - 1, 0, 0, 0)),
                           (E.ABS_Y, evdev.AbsInfo(0, 0, TOUCH_H - 1, 0, 0, 0)),
                           (E.ABS_MT_SLOT, evdev.AbsInfo(0, 0, 0, 0, 0, 0)),
                           (E.ABS_MT_TRACKING_ID, evdev.AbsInfo(0, 0, 65535, 0, 0, 0)),
                           (E.ABS_MT_POSITION_X, evdev.AbsInfo(0, 0, TOUCH_W - 1, 0, 0, 0)),
                           (E.ABS_MT_POSITION_Y, evdev.AbsInfo(0, 0, TOUCH_H - 1, 0, 0, 0))]}
        try:
            self.touch = evdev.UInput(caps, name="rg35xxh virtual touch", input_props=[E.INPUT_PROP_DIRECT])
        except (OSError, evdev.UInputError) as e:
            log.warning("cannot hide the pointer (virtual touch): %s", e)
            self._ui_send("target", "hide")
            return
        GLib.timeout_add(400, self._touch_tap)       # let libinput pick the new device up first

    def _touch_tap(self):
        t = self.touch
        if self.core.mode == "gamepad":
            x, y = TOUCH_TAP
            for code, v in ((E.ABS_MT_SLOT, 0), (E.ABS_MT_TRACKING_ID, 1), (E.ABS_MT_POSITION_X, x),
                            (E.ABS_MT_POSITION_Y, y), (E.ABS_X, x), (E.ABS_Y, y)):
                t.write(E.EV_ABS, code, v)
            t.write(E.EV_KEY, E.BTN_TOUCH, 1)
            t.syn()
            t.write(E.EV_ABS, E.ABS_MT_TRACKING_ID, -1)
            t.write(E.EV_KEY, E.BTN_TOUCH, 0)
            t.syn()
        GLib.timeout_add(300, self._touch_close)
        return False

    def _touch_close(self):
        if self.touch:
            self.touch.close()
            self.touch = None
        self._ui_send("target", "hide")
        return False

    # ------------------------------------------------ mode-change feedback
    def _mode_feedback(self, new):
        """Shake the old mode's taskbar icon and wobble the motor, then show the new icon."""
        if getattr(self, "preview", None) is not None:      # a slider preview gives way
            GLib.source_remove(self.preview_timer)
            self.preview = None
        if self.anim:
            GLib.source_remove(self.anim["timer"])
            self.anim = None
        if self.icon_mode == new:
            set_flag(INPUTMODE_FRAME, False)
            self._signal_waybar()
            return
        self.anim = {"old": self.icon_mode, "new": new, "k": 0}
        self._anim_step()
        self.anim["timer"] = GLib.timeout_add(SPRING_STEP_MS, self._anim_step)

    def _anim_step(self):
        an = self.anim
        k = an["k"]
        if k < len(ICON_FRAMES):
            with open(runtime_flag(INPUTMODE_FRAME), "w") as f:
                f.write(f"{an['old']} {ICON_FRAMES[k]}\n")
            eid = self.step_ids.get((self._magnitude(SPRING_PULSES[k]), SPRING_PULSE_MS))
            if eid is not None:
                GLib.timeout_add(HAPTIC_LAG_MS, self._play_effect, eid)
            an["k"] = k + 1
            self._signal_waybar()
            return True
        set_flag(INPUTMODE_FRAME, False)
        self.icon_mode = an["new"]
        self.anim = None
        self._signal_waybar()
        return False

    def _signal_waybar(self):
        """SIGRTMIN+WAYBAR_SIGNAL to Waybar (re-runs rg35xxh-inputmode). Cheaper than pkill."""
        for _ in range(2):
            if self.waybar_pid is None or _comm(self.waybar_pid) != "waybar":   # gone or restarted
                self.waybar_pid = next((int(d) for d in os.listdir("/proc") if d.isdigit()
                                        and _comm(d) == "waybar"), None)
                if self.waybar_pid is None:
                    return
            if _proc_age(self.waybar_pid) < 3:     # starting up: a real-time signal would kill it
                return
            try:
                os.kill(self.waybar_pid, signal.SIGRTMIN + WAYBAR_SIGNAL)
                return
            except ProcessLookupError:
                self.waybar_pid = None

    # ------------------------------------------- rumble from the virtual pad
    _EV = struct.Struct("llHHi")

    def _on_pad_fd(self, fd, cond):
        if not self.pad:
            return False
        try:
            data = os.read(fd, self._EV.size * 16)
        except BlockingIOError:
            return True
        except OSError:
            return True
        for i in range(0, len(data) - self._EV.size + 1, self._EV.size):
            _, _, etype, code, value = self._EV.unpack_from(data, i)
            try:
                if etype == E.EV_UINPUT and code == E.UI_FF_UPLOAD:
                    # acknowledge at once; the hardware upload goes through the motor gate
                    up = self.pad.begin_upload(value)
                    eff = ff.Effect.from_buffer_copy(up.effect)
                    if eff.ff_replay.length == 0:          # endless: cap it, re-trigger while playing
                        eff.ff_replay.length = MOTOR_GAME_MAX_MS
                        self.motor_game_endless.add(up.effect.id)
                    else:
                        self.motor_game_endless.discard(up.effect.id)
                    self.motor_pending_upload[up.effect.id] = eff
                    up.retval = 0
                    self.pad.end_upload(up)
                    self._motor_kick()
                elif etype == E.EV_UINPUT and code == E.UI_FF_ERASE:
                    er = self.pad.begin_erase(value)
                    self.motor_pending_upload.pop(er.effect_id, None)
                    self.motor_pending_play.pop(er.effect_id, None)
                    self.motor_game_endless.discard(er.effect_id)
                    self.motor_game_active.discard(er.effect_id)
                    phys = self.pad_ff.pop(er.effect_id, None)
                    if phys is not None:
                        self.gamepad.erase_effect(phys)
                    er.retval = 0
                    self.pad.end_erase(er)
                elif etype == E.EV_FF and (code in self.pad_ff or code in self.motor_pending_upload):
                    self.motor_pending_play[code] = value
                    self._motor_kick()
            except Exception as e:  # rumble is best effort
                log.debug("rumble forward: %s", e)
        return True

    # ---------------------------------------------------------------- run
    def _quit(self):
        self._loop.quit()
        return False

    # ------------------------------------------------- BT Controller mode
    def _request_bt(self):
        """SIGUSR2 (External Controller app): connect to the running external-controller service
        (rg35xxh-btpad or rg35xxh-usbpad) and send it the controls."""
        if self.bt:
            return True
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
            s.settimeout(1.0)
            s.connect(EXT_SOCKET)
            hello = s.recv(64)
            s.settimeout(0.2)
        except OSError as e:
            log.warning("External controller: cannot connect to %s: %s", EXT_SOCKET, e)
            spawn("notify-send", "-t", "5000", "External Controller", "Could not connect to the controller service")
            return True
        self.ext = EXT_HELLO.get(hello, "bt")
        self.bt = s
        self.bt_watch = GLib.io_add_watch(s.fileno(), GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, self._on_bt_data)
        log.info("%s: connected to %s", EXT_MODES[self.ext][1], EXT_SOCKET)
        if self.core.mode == "gamepad":           # local gamepad mode -> BT Controller mode
            self._destroy_pad()
            set_flag("rg35xxh-gamepad-mode", False)
            self.core.request_gamepad(combo_exit=True, f_buttons=self.ext in SWITCH_EXTS)
            self._run([("mode", "gamepad")] + [("pad_abs", PAD_AXES[n], int(round(v * 32767)))
                                               for n, v in self.core.axes.items()])
        else:
            self._run(self.core.request_gamepad(combo_exit=True, f_buttons=self.ext in SWITCH_EXTS))
        return True

    def _bt_send(self, etype, code, value):
        try:
            self.bt.send(BT_EVENT.pack(etype, code, value))
        except OSError as e:
            log.warning("BT Controller: send failed: %s", e)
            self._bt_lost()

    def _on_bt_data(self, fd, cond):
        """Message from the service (vibration), or EOF / hang-up: the service stopped."""
        data = b""
        if cond & GLib.IO_IN:
            try:
                data = self.bt.recv(64)
            except BlockingIOError:
                return True
            except OSError:
                data = b""
        if data.startswith(b"rumble "):
            try:
                big, small = (int(v) for v in data.split()[1:3])
                self._ext_rumble(big, small)
            except ValueError:
                pass
            return True
        if data:
            return True                            # unknown message: ignore
        self.bt_watch = None
        self._bt_lost()
        return False

    def _ext_rumble(self, big, small):
        """Vibration requested by the PC (Wired, or BT with the Xbox profile): the stronger of the two motors' values, on the
        handheld's single motor, through the motor gate. Runs until the PC sends 0 0 / the mode ends."""
        self.motor_ext_want = round(max(big, small) / 255 * MOTOR_LEVELS)
        self._motor_kick()

    # ------------------------------------------------ motor gate (see MOTOR_INTERVAL)
    def _motor_kick(self):
        if self.motor_timer:
            return
        wait = max(0.0, self.motor_last + MOTOR_INTERVAL - time.monotonic())
        self.motor_timer = GLib.timeout_add(int(wait * 1000), self._motor_flush)

    def _motor_ok(self):
        return self.gamepad is not None and E.EV_FF in self.gamepad.capabilities()

    def _ext_levels_upload(self):
        """One fixed-length effect per strength level, uploaded while the motor is idle."""
        if self.motor_ext_ids:
            return
        for lvl in range(1, MOTOR_LEVELS + 1):
            mag = lvl * 0xFFFF // MOTOR_LEVELS
            rumble = ff.Rumble(strong_magnitude=mag, weak_magnitude=mag)
            eff = ff.Effect(E.FF_RUMBLE, -1, 0, ff.Trigger(0, 0), ff.Replay(MOTOR_EFFECT_MS, 0),
                            ff.EffectType(ff_rumble_effect=rumble))
            self.motor_ext_ids[lvl] = self.gamepad.upload_effect(eff)

    def _ext_levels_free(self):
        for eid in self.motor_ext_ids.values():
            try:
                self.gamepad.write(E.EV_FF, eid, 0)
                self.gamepad.erase_effect(eid)
            except OSError:
                pass
        self.motor_ext_ids = {}
        self.motor_ext_applied = 0
        self.motor_ext_want = 0

    def _motor_flush(self):
        self.motor_timer = None
        if not self._motor_ok():
            self.motor_pending_upload.clear()
            self.motor_pending_play.clear()
            return False
        self.motor_last = time.monotonic()
        if self.pad is None:          # no game pad (any more): nothing of a game's may play
            self.motor_pending_upload.clear()
            self.motor_pending_play.clear()
        try:
            # games (virtual pad): latest upload per effect, then play/stop changes
            for vid, eff in list(self.motor_pending_upload.items()):
                existing = self.pad_ff.get(vid)
                eff.id = existing if existing is not None else -1
                self.pad_ff[vid] = self.gamepad.upload_effect(eff)
            self.motor_pending_upload.clear()
            for vid, val in list(self.motor_pending_play.items()):
                if vid in self.pad_ff:
                    self.gamepad.write(E.EV_FF, self.pad_ff[vid], val)
                    if vid in self.motor_game_endless and val:
                        self.motor_game_active.add(vid)
                    else:
                        self.motor_game_active.discard(vid)
            self.motor_pending_play.clear()
            # PC (external modes): switch between the pre-uploaded level effects
            want = self.motor_ext_want
            if want != self.motor_ext_applied:
                if self.motor_ext_applied and self.motor_ext_applied in self.motor_ext_ids:
                    self.gamepad.write(E.EV_FF, self.motor_ext_ids[self.motor_ext_applied], 0)
                if want:
                    self._ext_levels_upload()
                    self.gamepad.write(E.EV_FF, self.motor_ext_ids[want], 1)
                self.motor_ext_applied = want
        except OSError as e:
            log.debug("motor: %s", e)
        self._motor_refresh_schedule()
        return False

    def _motor_refresh_schedule(self):
        if self.motor_refresh_timer is None and (self.motor_ext_applied or self.motor_game_active):
            self.motor_refresh_timer = GLib.timeout_add(int(MOTOR_REFRESH * 1000), self._motor_refresh)

    def _motor_refresh(self):
        """Re-trigger long vibrations before their fixed-length effect runs out."""
        self.motor_refresh_timer = None
        if not self._motor_ok():
            return False
        try:
            if self.motor_ext_applied in self.motor_ext_ids:
                self.gamepad.write(E.EV_FF, self.motor_ext_ids[self.motor_ext_applied], 1)
            for vid in list(self.motor_game_active):
                if vid in self.pad_ff:
                    self.gamepad.write(E.EV_FF, self.pad_ff[vid], 1)
        except OSError as e:
            log.debug("motor refresh: %s", e)
        self._motor_refresh_schedule()
        return False

    def _bt_lost(self):
        if not self.bt:
            return
        log.info("%s: service ended, back to desktop mode", EXT_MODES[self.ext][1])
        actions = self.core.request_desktop()
        if actions:
            self._run(actions)                    # closes the socket via the "mode" action
        else:
            self._bt_close()

    def _bt_close(self):
        if self._motor_ok():
            self._ext_levels_free()               # stop any vibration the PC left on
        if self.bt_watch:
            GLib.source_remove(self.bt_watch)
            self.bt_watch = None
        if self.bt:
            try:
                self.bt.close()                   # btpad sees EOF and stops
            except OSError:
                pass
            self.bt = None
            log.info("%s: disconnected", EXT_MODES[self.ext][1])
        for flag, *_ in EXT_MODES.values():
            set_flag(flag, False)
        if os.path.exists(runtime_flag(EXT_DARK)):      # battery saver left the display off
            log.info("%s: display was still off, switching it on", EXT_MODES[self.ext][1])
            spawn("wlopm", "--on", EXT_OUTPUT)
            set_flag(EXT_DARK, False)

    def run(self):
        GLib.timeout_add(10, self._tick)
        self.beats = 0
        self._heartbeat()
        GLib.timeout_add(HEARTBEAT_MS, self._heartbeat)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR1, self._recenter)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR2, self._request_bt)
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            GLib.unix_signal_add(GLib.PRIORITY_HIGH, sig, self._on_term, sig)
        # A plain GLib main loop (no GTK in this process, see ui.py). Quitting PyGObject's Gtk.main()
        # from a signal handler deadlocked (7 of 8 tries on the device); ui.py avoids it too.
        self._loop = GLib.MainLoop()
        self._loop.run()

    # Watchdog (rg35xxh-inputd wrapper): the daemon grabs every button, the power key included, so
    # a hung main loop would leave no way to switch the handheld off but the power chip's forced
    # cut. The main loop writes a counter here every second; the wrapper restarts a daemon whose
    # counter stops. The file exists only while the main loop runs (not during start-up or the
    # clean exit), so neither is mistaken for a hang.
    def _heartbeat(self):
        self.beats += 1
        try:
            with open(HEARTBEAT, "w") as f:
                f.write(f"{self.beats}\n")
        except OSError as e:
            log.warning("heartbeat: %s", e)
        return True

    def _on_term(self, sig):
        log.info("%s: clean exit", signal.Signals(sig).name)
        self._quit()
        return False

    # ------------------------------------------------ clean exit
    # SIGTERM (log-out: the next session's autostart stops this one), SIGINT/SIGHUP and errors all
    # end here. We stop the motor and free every vibration effect, the virtual devices and the grabs
    # ourselves, one step at a time, instead of leaving it all to the kernel's teardown when the
    # process dies -- while the next session's daemon may already be grabbing the same gamepad and
    # uploading its effects. The joypad driver's vibration path (ff-memless + PWM work) has locked
    # the whole system up before (see MOTOR_INTERVAL); a log-out that killed the old daemon right as
    # the new one started froze the handheld (input, Wi-Fi, SSH) and needed a battery reset.
    # The single-instance lock (main) makes the next daemon wait until this one is gone.
    def cleanup(self):
        # Also runs for a daemon that was stopped during start-up (__init__ not finished), so
        # every attribute may still be missing: read them with get().
        def step(what, fn, *a):
            try:
                fn(*a)
            except Exception as e:      # keep going: every later step still matters
                log.warning("clean exit: %s: %s", what, e)

        def get(name, default=None):
            return getattr(self, name, default)
        try:
            os.unlink(HEARTBEAT)                    # disarm the watchdog: exiting, not hung
        except FileNotFoundError:                   # (not armed yet: stopped during start-up)
            pass
        if get("macro"):
            step("macro", self._macro_stop, "daemon exit")      # let go of what it holds
        if get("owners"):
            step("held keys", self._release_owned)

        if get("focus") is not None:
            step("focus watcher", get("focus").close)
        if get("ui_retry"):
            step("ui_retry", GLib.source_remove, get("ui_retry"))
            self.ui_retry = None
        if get("bt"):
            step("external controller", self._bt_close)   # stops + frees the PC's vibration levels
        step("vibration effects", self._release_effects)    # stop, then erase all (games' too)
        if get("pad"):
            step("virtual pad", self._destroy_pad)
        if get("touch") is not None:
            step("touch", self._touch_close)
        if get("ui") is not None:
            step("on-screen keyboard process", self._ui_stop, "stopped")
        for d in list(get("devices", [])):
            step("ungrab %s" % d.path, d.ungrab)
            step("close %s" % d.path, d.close)
        self.devices = []
        self.gamepad = None
        for name in ("mouse", "keyboard"):
            if get(name) is not None:
                step(name, get(name).close)
        for flag in ("rg35xxh-gamepad-mode", "rg35xxh-bt-mode", "rg35xxh-wired-mode", INPUTMODE_FRAME):
            step(flag, set_flag, flag, False)
        log.info("clean exit: gamepad, vibration and virtual devices released")


HEARTBEAT = runtime_flag("rg35xxh-inputd.alive")   # see _heartbeat (watchdog)
HEARTBEAT_MS = 1000
LOCK_WAIT = 10.0   # s: how long a new daemon waits for the previous one to finish its clean exit


def single_instance():
    """One daemon at a time (see "clean exit"): returns the held lock file, or None if another
    daemon still runs after LOCK_WAIT. The kernel drops the lock when the holder's process is gone,
    so the next daemon never grabs the gamepad while the old one still owns effects on it."""
    import fcntl
    f = open(runtime_flag("rg35xxh-inputd.lock"), "w")
    deadline = time.monotonic() + LOCK_WAIT
    waited = False
    while True:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if waited:
                log.info("previous daemon gone, starting")
            return f
        except BlockingIOError:
            if time.monotonic() >= deadline:
                f.close()
                return None
            if not waited:
                log.info("previous daemon still running: waiting up to %.0f s", LOCK_WAIT)
                waited = True
            time.sleep(0.2)


def main():
    # Touch $XDG_RUNTIME_DIR/rg35xxh-inputd.debug and restart the daemon to log every key event.
    debug = os.path.exists(runtime_flag("rg35xxh-inputd.debug"))
    logging.basicConfig(level=logging.DEBUG if debug else logging.INFO, stream=sys.stderr,
                        format="%(asctime)s %(levelname)s %(message)s")
    lock = single_instance()
    if lock is None:
        log.error("another rg35xxh-inputd still runs; not starting a second one")
        sys.exit(1)
    # Until the main loop installs its own handlers: SIGTERM during start-up still exits through
    # cleanup (Python's default would just die). The object exists before __init__ runs, so a
    # half-started daemon is cleaned up too.
    def early_exit(sig, _frame):
        log.info("%s during start-up: clean exit", signal.Signals(sig).name)
        sys.exit(0)
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, early_exit)
    d = Daemon.__new__(Daemon)
    try:
        d.__init__()
        d.run()
    finally:
        d.cleanup()
        lock.close()


if __name__ == "__main__":
    main()
